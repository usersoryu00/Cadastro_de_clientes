clientes = []
estados_civis = {
    1: "Solteiro(a)",
    2: "Casado(a)",
    3: "Divorciado(a)",
    4: "Viúvo(a)"
}


def cadastrar_cliente() :
    nome = input("Nome do cliente: ")
    idade = int(input("Idade: "))
    
    print("Estado civil: ")
    for k, v in estados_civis.items():
        print(f"{k}.{v}")
    opcao_estado = int(input("Digite o número correspondente:"))
    estado_civil = estados_civis.get(opcao_estado, "Não informado")
    
    possui_veiculo = input("Possui veículo? (S/N): ").lower() == 'S'
    veiculo = {}
    
    if possui_veiculo:
        veiculo['Modelo'] = input("Modelo do veículo: ")
        veiculo['Placa'] = input("Placa de veículo: ")
        veiculo['Ano'] = input("Ano de fabricação: ")
        
    cliente ={
        'Nome': nome,
        'Idade': idade,
        'Estado civil': estado_civil,
        'Veiculo': veiculo if possui_veiculo else None
}
    clientes.append(cliente)
    print("Cliente cadastrado com sucesso!|\n")  
    
    def listar_clientes():
        if not clientes:
            print("Nenhum cliente cadastrado.\n")
            return 
        
        for i, c in enumerate(clientes, 1):
            print(f"Cliente {i}: {c['nome']} ({c['idade']} anos) - {c['estado_civil']}")
            if c['Veiculo']:
                print(f" Veiculo: {c['Veiculo']['Modelo']} | Placa: {c['Veiculo']['Placa']} | Ano: {c['Veiculo']['Ano']}")
                print()
                
def buscar ():
    termo = input("Buscarpor nome, modelo ou placa: ").lower()
    encontrados = []
    
    for c in clientes:
        if termo in c['nome'].lower():
            encontrados.append(c)
        
        elif c['Veiculo']: 
            if termo in c['Veiculo']['Modelo'].lower() or termo in c['Veiculo']['Placa'].lower():
               encontrados.append(c)
    
    
    if encontrados:
        for c in encontrados: 
            print(f"Cliente: {c['nome']}({c['idade']} anos - {c['estado_civil']} ")
            if c['Veiculo']:
                print(f"Veiculo:{c['Veiculo']['Modelo']} | Placa: {c['Veiculo']['Placa']} | Ano: {c['Veiculo']['Ano']}")
            print()
    else:
        print("Nenhum resultado encontrado.\n")
                
                  